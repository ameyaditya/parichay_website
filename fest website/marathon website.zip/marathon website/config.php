<?php
	const DB_HOST = 'localhost';
	const DB_USER = 'root';
	const DB_PASS = '';
	const DB_NAME = 'parichay_marathon';
	const merchantMid = "qXpShT71788695022363";
	const merchantKey = "hzCa6Abazym!!fBD";
	const SALT = "iamverygoodatmathematicsinbiologyatcarjockeyrides.";
	?>